var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");
ctx.font = "30px Arial";

let dr=0.1;
let n=300;
let sw=300;
let sh=300;
let md=20;
let q=50;

var x=1/2;
var y=1/2;
var r=0;
var z=0;
var steps=0;
var outOnSteps=0;

var bx=[];
var by=[];
var bs=[];

var nb=0;
for (var i=0; i<q; i++){
	for (var j=0; j<q; j++){
		let tx=i-q/2;
		let ty=j-q/2;
		bx[nb]=tx+1/2;
		by[nb]=ty+1/2;
		if (tx==0 && ty==0){
			bs[nb]=2;	
		} else {
			bs[nb]=Math.floor(Math.random()*3);
		}
		nb++;
	}	
}

render();
ctx.fillStyle = "red";
ctx.fillText("Get out!", 100, 150);

function render(){
	if (z==0){
    	ctx.fillStyle = "#FFFFFF";
	} else {
		ctx.fillStyle = "#000000";	
	}
	ctx.fillRect(0,0,sw,sh);
	for (var i=0; i<n; i++){
		let lx=x;
		let ly=y;
		for (var j=0; j<n; j++){
			lx=lx+Math.sin((i/n/2-1/4+r)*Math.PI)/n*md;
			ly=ly+Math.cos((i/n/2-1/4+r)*Math.PI)/n*md;
			if (Math.abs(lx-Math.round(lx))<0.1 || Math.abs(ly-Math.round(ly))<0.1){
				for (var k=0; k<nb; k++){
					if (lx>bx[k]-1/2 && lx<bx[k]+1/2 && ly>by[k]-1/2 && ly<by[k]+1/2 && bs[k]==z){
						let d=Math.sqrt(Math.pow(x-lx,2)+Math.pow(y-ly,2));
						let h=1/(d*Math.cos((i/n/2-1/4)*Math.PI));
						let tx=lx-bx[k];
						let ty=ly-by[k];
						var w;
						if (tx>0 && Math.abs(tx)>Math.abs(ty)){
							if (z==0){
								w = "#66CC66";	
							} else {
								w = "#6666CC";	
							}				
						}
						if (tx<0 && Math.abs(tx)>Math.abs(ty)){
							if (z==0){
								w = "#335533";	
							} else {
								w = "#333355";	
							}					
						}
						if (ty>0 && Math.abs(ty)>Math.abs(tx)){
							if (z==0){
								w = "#99FF99";	
							} else {
								w = "#9999FF";	
							}				
						}
						if (ty<0 && Math.abs(ty)>Math.abs(tx)){
							if (z==0){
								w = "#009900";	
							} else {
								w = "#000099";	
							}				
						}
						ctx.fillStyle=w;
						ctx.fillRect(sw*i/n, sh/2*(1-h), sw/n, sh*h);
						k=nb;
						j=n;
					}
				}
			}
		}	
	}
	ctx.fillStyle = "red";
	ctx.fillText(steps, 10, 30);
	ctx.fillText("NW       N       NE       E       SE       S       SW       W       NW       N       NE       E       SE       S       SW       W       NW       N       NE", -710-(r%2)*360, 290);
}

function forward() {
  let ty=y+Math.cos(-r*Math.PI);
  let tx=x-Math.sin(-r*Math.PI);
  if (!collision(tx,ty,bx,by,bs)){
  	x=tx;
	y=ty;
	steps++;
  }
  render();
  gameCompleted();
  inShiftZone();
}

function backward() {
  let ty=y-Math.cos(-r*Math.PI);
  let tx=x+Math.sin(-r*Math.PI);
   if (!collision(tx,ty,bx,by,bs)){
  	x=tx;
	y=ty;
	steps++;
  }
  render();
  gameCompleted();
  inShiftZone();
}

function right() {
	r=r+dr;
	render();
  	gameCompleted();
	inShiftZone();
}

function left(){
	r=r-dr;
	render();
	gameCompleted();
	inShiftZone();
}

function shift(){
	z++;
	z=z%2;
  	if (collision(x,y,bx,by,bs)){
		z++;
		z=z%2;
  	}  
	render();
}

function collision(tx,ty,ax,ay,as){
	let temp=false;
	for (var k=0;k<nb;k++){
		if (tx>ax[k]-1/2 && tx<ax[k]+1/2 && ty>ay[k]-1/2 && ty<ay[k]+1/2 && as[k]==z){
			temp=true;
		}
	}
	return temp;
}

function gameCompleted(){
	if ((x>q/2 || x<-q/2 || y>q/2 || y<-q/2) && outOnSteps==0){
		outOnSteps=steps;
	}
	if (outOnSteps!=0){
		ctx.fillStyle = "red";
		ctx.fillText("Out on " + outOnSteps + " steps!", 20, 150);
	}
}

function inShiftZone(){
	let temp=false;
	for (var k=0;k<nb;k++){
		if (x>bx[k]-1/2 && x<bx[k]+1/2 && y>by[k]-1/2 && y<by[k]+1/2 && bs[k]==2){
			temp=true;
		}
	}
	if (temp){
		document.getElementById("shiftButton").style.backgroundColor = "red";
	}
	else {
		document.getElementById("shiftButton").style.backgroundColor = "grey";	
	}
}